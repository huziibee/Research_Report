# 09 — Revision Changelog

## Preserved

- T00–T09 remain completed and are not rerun.
- Current post-T09 dataset work remains repository-driven; the obsolete dataset section of the proposal is not reinstated.

## Rebuilt sequence

- Replaced the unfinished T10–T35 plan with T10–T38.
- T10 now reconciles schema conflicts and migrates completed outputs.
- T11 freezes the research/governance contract before new work.
- Local model setup moved to T12.
- Mandatory fine-tuning moved into required T27–T28 gates.
- Protocol freeze and protected execution moved to T29–T30.

## Method additions

- Text-only scope; all LVLM work removed.
- Speech act, CPC, supplemental evidence, valid interpretation sets, and resolved-slot values.
- Context-sampling variance as an implemented uncertainty feature.
- Exact degree-based routing baseline.
- Seven mandatory systems retained.
- Deterministic intent/CPC/route evaluator with exact proposal metrics.
- Risk/capability/rejection/resolution correctness.
- AI-use, ethics, and model-licence governance.
- Fine-tuning-versus-architecture ablation design.

## Stretch policy

- Semantic verifier, robustness challenge suite, and repeated-run stability are retained as transparent nonblocking stretch tickets.
- Calendar feasibility is intentionally not used to cut scope.
