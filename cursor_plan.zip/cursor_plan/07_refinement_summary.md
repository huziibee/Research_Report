# 07 — Final Refinement Summary

This revision aligns the execution plan with the non-dataset methodology of the research proposal while preserving the completed T00–T09 work.

## Major corrections

- T00–T09 remain completed; T10 migrates rather than reruns them.
- Added authoritative schema v2 to resolve legacy risk/capability/interpretation conflicts.
- Added an early research contract, AI-use log, ethics determination, and model-licence register.
- Removed LVLM/raw-image scope entirely.
- Made local supervised fine-tuning mandatory for the proposed manager.
- Added the proposal-required context-sampling uncertainty component.
- Added explicit speech-act, CPC, supplemental-context, and resolved-slot structures.
- Required silent resolution to output and score actual resolved values.
- Kept all seven comparison systems mandatory.
- Defined the degree-based baseline precisely and prevented it from using type/risk semantics.
- Added exact proposal metric names/formulas and machine-enforced eligibility.
- Added layered failure analysis for interpretation, ambiguity, risk, capability, and routing.
- Added architecture-versus-adaptation ablations to separate fine-tuning gains from routing gains.
- Preserved semantic verification, robustness, and repeated runs as documented stretch/nonblocking work.
- Removed calendar/schedule constraints; only stage gates control progress.
