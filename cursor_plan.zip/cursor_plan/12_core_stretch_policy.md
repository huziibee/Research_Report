# 12 — Core and Stretch Completion Policy

Calendar limits are intentionally ignored. This policy exists only to prevent nonessential enhancements from making the central experiment impossible to audit.

## Mandatory core

T10–T24, T26–T33, T36–T38 are mandatory, including:

- schema migration;
- research/governance contract;
- local model setup;
- gold benchmark;
- all seven systems;
- context-sampling uncertainty;
- official deterministic evaluator;
- mandatory fine-tuning;
- freeze and protected execution;
- cost, statistics, ablations, failure analysis, reports, and audit.

## Stretch/nonblocking

- T25 semantic evaluator calibration;
- T34 robustness challenge suite;
- T35 repeated-run stability;
- optional safety challenge data inside T34.

Stretch work must still be honest and traceable. `NOT_APPLICABLE` or `BLOCKED_NONCRITICAL` is acceptable only with a reason and does not erase the planned item from final reporting.

## Seven-system exception

All seven comparison systems are mandatory regardless of their original proposal status. None may be reclassified as stretch.
